<?php 

$lang["error_no_permission_module"] = "sizin icazəniz yoxdur";
$lang["error_unknown"] = "naməlum";
