<?php 

$lang["suppliers_account_number"] = "Nomor Akun Pemasok";
$lang["suppliers_agency_name"] = "Nama";
$lang["suppliers_cannot_be_deleted"] = "Tidak bisa dihapus pemasok yang dipilih, satu atau lebih dari pemasok yang dipilih memiliki penjualan.";
$lang["suppliers_company_name"] = "Nama Perusahaan";
$lang["suppliers_company_name_required"] = "Nama Perusahaan wajib diisi";
$lang["suppliers_confirm_delete"] = "Apakah Anda yakin ingin menghapus pemasok yang dipilih?";
$lang["suppliers_confirm_restore"] = "";
$lang["suppliers_error_adding_updating"] = "Kesalahan Menambah / memperbarui data pemasok";
$lang["suppliers_new"] = "Pemasok Baru";
$lang["suppliers_none_selected"] = "Anda belum memilih pemasok untuk dihapus";
$lang["suppliers_one_or_multiple"] = "Pemasok";
$lang["suppliers_successful_adding"] = "Anda telah berhasil menambahkan data pemasok";
$lang["suppliers_successful_deleted"] = "Anda telah berhasil menghapus data pemasok";
$lang["suppliers_successful_updating"] = "Anda telah berhasil memperbarui data pemasok";
$lang["suppliers_supplier"] = "Pemasok";
$lang["suppliers_supplier_id"] = "ID";
$lang["suppliers_update"] = "Ubah data Pemasok";
