<?php 

$lang["datepicker_all_time"] = "Semua Waktu";
$lang["datepicker_apply"] = "Terapkan";
$lang["datepicker_cancel"] = "Batal";
$lang["datepicker_custom"] = "Kustom";
$lang["datepicker_from"] = "Dari";
$lang["datepicker_last_30"] = "30 Hari Terakhir";
$lang["datepicker_last_7"] = "7 Hari Terakhir";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Bulan lalu";
$lang["datepicker_last_year"] = "Tahun lalu";
$lang["datepicker_same_month_last_year"] = "Bulan yang sama tahun kemarin";
$lang["datepicker_same_month_to_same_day_last_year"] = "Bulan yang sama untuk hari yang sama tahun yang lalu";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Bulan ini";
$lang["datepicker_this_year"] = "Tahun ini";
$lang["datepicker_to"] = "sampai";
$lang["datepicker_today"] = "Hari ini";
$lang["datepicker_today_last_year"] = "Hari ini tahun kemarin";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Kemarin";
