<?php 

$lang["error_no_permission_module"] = "";
$lang["error_unknown"] = "";
