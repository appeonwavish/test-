package com.ys.onecache;

public interface UserMapper {
	//根据用户id查询用户信息，以及用户下面的所有订单信息
	public User selectUserByUserId(int UserId);
	
	//根据UserID更新用户信息
	public int updateUserByUserId(User user);

}
