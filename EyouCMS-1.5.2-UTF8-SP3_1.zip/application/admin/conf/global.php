<?php
/**
 * 配置常量
 */
return array(
    
);
