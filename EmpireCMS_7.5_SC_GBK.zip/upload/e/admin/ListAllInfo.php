<?php
define('EmpireCMSAdmin','1');
require('../class/connect.php');
require('../class/db_sql.php');
require('../class/functions.php');
require LoadLang("pub/fun.php");
require("../data/dbcache/class.php");
$link=db_connect();
$empire=new mysqlquery();
//��֤�û�
$lur=is_login();
$logininid=$lur['userid'];
$loginin=$lur['username'];
$loginrnd=$lur['rnd'];
$loginlevel=$lur['groupid'];
$loginadminstyleid=$lur['adminstyleid'];
//ehash
$ecms_hashur=hReturnEcmsHashStrAll();
//ȡ�����ݱ�
$tid=(int)$public_r['tid'];
$tbname=$_GET['tbname']?$_GET['tbname']:$public_r['tbname'];
$tbname=RepPostVar($tbname);
$changetbs='';
$havetb=0;
$tbsql=$empire->query("select tid,tbname,tname from {$dbtbpre}enewstable order by tid");
while($tbr=$empire->fetch($tbsql))
{
	$selected='';
	if($tbname==$tbr[tbname])
	{
		$tid=$tbr[tid];
		$selected=' selected';
		$havetb=1;
	}
	$changetbs.="<option value='".$tbr[tbname]."'".$selected.">".$tbr[tname]."(".$tbr[tbname].")</option>";
}
if($havetb==0)
{
	printerror('ErrorUrl','');
}
//ȡ����Ӧ����Ϣ
$user_r=$empire->fetch1("select groupid,adminclass from {$dbtbpre}enewsuser where userid='$logininid'");
//ȡ���û���
$gr=$empire->fetch1("select doall,doselfinfo from {$dbtbpre}enewsgroup where groupid='$user_r[groupid]'");
//����Ա
$where='';
$and='';
$ewhere='';
$search="&tbname=$tbname".$ecms_hashur['ehref'];
$ecmscheck=(int)$_GET['ecmscheck'];
$addecmscheck='';
$indexchecked=1;
if($ecmscheck)
{
	$search.='&ecmscheck='.$ecmscheck;
	$addecmscheck='&ecmscheck='.$ecmscheck;
	$indexchecked=0;
}
$infotb=ReturnInfoMainTbname($tbname,$indexchecked);
//�Ż�
$modid=$etable_r[$tbname][mid];
$yhadd='';
$yhvar='hlist';
$yhid=$etable_r[$tbname][yhid];
if($yhid)
{
	$yhadd=ReturnYhSql($yhid,$yhvar);
	if($yhadd)
	{
		$and=$where?' and ':' where ';
		$where.=$and.$yhadd;
	}
}
if(empty($yhadd))
{
	//ʱ�䷶Χ
	$infolday=(int)$_GET['infolday'];
	if(empty($infolday))
	{
		$infolday=$public_r['infolday'];
	}
	if($infolday&&$infolday!=1)
	{
		$ckinfolday=time()-$infolday;
		$and=$where?' and ':' where ';
		$where.=$and."newstime>'$ckinfolday'";
		$search.="&infolday=$infolday";
	}
	if($infolday==1)
	{
		$search.="&infolday=$infolday";
	}
}
if(!$gr['doall'])
{
	$cids='';
	$a=explode("|",$user_r['adminclass']);
	for($i=1;$i<count($a)-1;$i++)
	{
		$dh=',';
		if(empty($cids))
		{
			$dh='';
		}
		$cids.=$dh.$a[$i];
	}
	if($cids=='')
	{
		$cids=0;
	}
	$and=$where?' and ':' where ';
	$where.=$and.'classid in ('.$cids.')';
}
//ֻ�ܱ༭�Լ�����Ϣ
if($gr['doselfinfo'])
{
	$and=$where?' and ':' where ';
	$where.=$and."userid='$logininid' and ismember=0";
}
$url="<a href=ListAllInfo.php?tbname=".$tbname.$addecmscheck.$ecms_hashur['ehref'].">������Ϣ</a>";
$start=0;
$page=(int)$_GET['page'];
$page=RepPIntvar($page);
$line=intval($public_r['hlistinfonum']);//ÿҳ��ʾ
$page_line=21;
$offset=$page*$line;
//��ĿID
$classid=intval($_GET['classid']);
if($classid)
{
	$and=$where?' and ':' where ';
	if($class_r[$classid][islast])
	{
		$where.=$and."classid='$classid'";
	}
	else
	{
		$where.=$and."(".ReturnClass($class_r[$classid][sonclass]).")";
	}
	$search.="&classid=$classid";
}
//ģ��
$infomod_r=$empire->fetch1("select mid,listfile from {$dbtbpre}enewsmod where mid='$modid'");
//�������
$ttid=(int)$_GET['ttid'];
if($ttid)
{
	$and=$where?' and ':' where ';
	$where.=$and."ttid='$ttid'";
	$search.="&ttid=$ttid";
}
//�������
$tts='';
$ttsql=$empire->query("select typeid,tname from {$dbtbpre}enewsinfotype where mid='$infomod_r[mid]' order by myorder");
while($ttr=$empire->fetch($ttsql))
{
	$select='';
	if($ttr[typeid]==$ttid)
	{
		$select=' selected';
	}
	$tts.="<option value='$ttr[typeid]'".$select.">$ttr[tname]</option>";
}
$stts=$tts?"<select name='ttid'><option value='0'>�������</option>$tts</select>":"";
//����
$showisgood=(int)$_GET['showisgood'];
$showfirsttitle=(int)$_GET['showfirsttitle'];
$sear=(int)$_GET['sear'];
if($sear)
{
	$and=$where?' and ':' where ';
	$showspecial=(int)$_GET['showspecial'];
	if($showspecial==1)//�ö�
	{
		$where.=$and.'istop>0';
	}
	elseif($showspecial==2)//�Ƽ�
	{
		$where.=$and.'isgood>0';
	}
	elseif($showspecial==3)//ͷ��
	{
		$where.=$and.'firsttitle>0';
	}
	elseif($showspecial==5)//ǩ��
	{
		$where.=$and.'isqf=1';
	}
	elseif($showspecial==7)//Ͷ��
	{
		$where.=$and.'ismember=1';
	}
	elseif($showspecial==8)//�ҵ���Ϣ
	{
		$where.=$and."userid='$logininid' and ismember=0";
	}
	$and=$where?' and ':' where ';
	//�Ƽ�
	if($showisgood)
	{
		if($showisgood>0)
		{
			$where.=$and."isgood='$showisgood'";
		}
		else
		{
			$where.=$and.'isgood>0';
		}
	}
	$and=$where?' and ':' where ';
	//ͷ��
	if($showfirsttitle)
	{
		if($showfirsttitle>0)
		{
			$where.=$and."firsttitle='$showfirsttitle'";
		}
		else
		{
			$where.=$and.'firsttitle>0';
		}
	}
	$and=$where?' and ':' where ';
	if($_GET['keyboard'])
	{
		$keyboard=RepPostVar2($_GET['keyboard']);
		$show=RepPostStr($_GET['show'],1);
		if($show==0)//����ȫ��
		{
			$where.=$and."(title like '%$keyboard%' or username like '%$keyboard%' or id='$keyboard' or keyboard like '%$keyboard%')";
		}
		elseif($show==1)//��������
		{
			$where.=$and."(title like '%$keyboard%')";
		}
		elseif($show==3)//ID
		{
			$where.=$and."(id='$keyboard')";
		}
		elseif($show==4)//�����ؼ���
		{
			$where.=$and."(keyboard like '%$keyboard%')";
		}
		else
		{
			$where.=$and."(username like '%$keyboard%')";
		}
	}
	$search.="&sear=1&keyboard=$keyboard&show=$show&showspecial=$showspecial&showisgood=$showisgood&showfirsttitle=$showfirsttitle";
}
//��ʾ�ظ�����
if($_GET['showretitle']==1)
{
	$and=$where?' and ':' where ';
	$search.="&showretitle=1&srt=".intval($_GET['srt']);
	$addsrt="";
	$srtid="";
	$first=1;
	$srtsql=$empire->query("select id,title from ".$infotb." group by title having(count(*))>1");
	while($srtr=$empire->fetch($srtsql))
	{
		if($first==1)
		{
			$addsrt.="title='".addslashes($srtr['title'])."'";
			$srtid.=$srtr['id'];
			$first=0;
		}
		else
		{
			$addsrt.=" or title='".addslashes($srtr['title'])."'";
			$srtid.=",".$srtr['id'];
		}
	}
	if(!empty($addsrt))
	{
		if($_GET['srt']==1)
		{
			$where.=$and."(".$addsrt.") and id not in (".$srtid.")";
		}
		else
		{
			$where.=$and."(".$addsrt.")";
		}
	}
	else
	{
		printerror("HaveNotReInfo","ListAllInfo.php?tbname=".$tbname.$addecmscheck.$ecms_hashur['ehref']);
	}
}
//����
$orderby=RepPostStr($_GET['orderby'],1);
$doorderby=$orderby?'asc':'desc';
$myorder=RepPostStr($_GET['myorder'],1);
if($myorder==1)//ID��
{$doorder="id";}
elseif($myorder==2)//ʱ��
{$doorder="newstime";}
elseif($myorder==5)//������
{$doorder="plnum";}
elseif($myorder==3)//����
{$doorder="onclick";}
elseif($myorder==4)//����
{$doorder="totaldown";}
else//Ĭ������
{$doorder="id";}
$doorder.=' '.$doorderby;
$search.="&myorder=$myorder&orderby=$orderby";
$totalquery="select count(*) as total from ".$infotb.$where;
//����Ϣ��
$tbinfos=eGetTableRowNum("{$dbtbpre}ecms_".$tbname);
$tbckinfos=eGetTableRowNum("{$dbtbpre}ecms_".$tbname."_check");
//ȡ��������
$totalnum=intval($_GET['totalnum']);
if($totalnum<1)
{
	if(empty($where))
	{
		$num=$indexchecked==1?$tbinfos:$tbckinfos;
	}
	else
	{
		$num=$empire->gettotal($totalquery);
	}
}
else
{
	$num=$totalnum;
}
$search1=$search;
$search.="&totalnum=$num";
$returnpage=page2($num,$line,$page_line,$start,$page,$search);
$phpmyself=urlencode(eReturnSelfPage(1));
//����ҳ��
$deftempfile=ECMS_PATH.'e/data/html/list/alllistinfo.php';
if($infomod_r[listfile])
{
	$tempfile=ECMS_PATH.'e/data/html/list/all'.$infomod_r[listfile].'.php';
	if(!file_exists($tempfile))
	{
		$tempfile=$deftempfile;
	}
}
else
{
	$tempfile=$deftempfile;
}
require($tempfile);
db_close();
$empire=null;
?>