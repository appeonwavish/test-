<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<if value="$c['met_agents_metmsg'] eq 1">
<div class="alert alert-primary tips w-100">如果需安装自己制作的模板，请到应用市场安装 <a href="#/myapp/free">模板制作助手</a></div>
</if>
<div class="content metadmin-content-min bg-white p-4">
  <div class="met-template-list row">
  </div>
</div>