<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<div class="met-partner">
	<nav class="nav nav-underline rounded-xs mb-3 py-2 metadmin-content-min bg-white"></nav>
	<div class="tab-content"></div>
</div>