<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<button type="button" class="btn btn-primary" table-addlist="{$table_addlist}"<if value="$table_newid">data-table-newid='1'</if>>{$word.add}</button>