<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<div class="met-myapp metadmin-content-min">
    <if value="$c['met_agents_metmsg']">
    <div class="met-myapp-right position-relative float-right">
    </div>
    </if>
    <div class="met-myapp-list row px-2"></div>
    <div class="app-detail"></div>
</div>