<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.

defined('IN_MET') or exit('No permission');

/**
 * 系统首页（全局）标签类
 */

class index_label
{
    /**
     * config字段变量
     */
    public function config()
    {

    }

    /**
     * 栏目数组
     */
    public function column()
    {

    }

    /**
     * 模板自定义参数
     */
    public function tem_config()
    {

    }

    /**
     * banner
     */
    public function banner()
    {

    }

    /**
     * page 分页标签
     */
    public function page()
    {

    }
}

# This program is an open source system, commercial use, please consciously to purchase commercial license.
# Copyright (C) MetInfo Co., Ltd. (http://www.metinfo.cn). All rights reserved.
?>
