<?php
#http://code.mapabc.com/class_javascript.html
$map_mid = '116.397428,39.909230';
$map_key = 'b0a7db0b3a30f944a21c3682064dc70ef5b738b062f6479a5eca39725798b1ee300bd8d5de3a4ae3';
?>