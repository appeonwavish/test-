<?php
#http://developer.baidu.com/map/jsdemo.htm
$map_mid = '116.404,39.915';
$map_key = '';
?>