<?php
$names = array (
  'qq' => '企业QQ(b.qq.com)',
  '53kf' => '53客服(www.53kf.com)',
  'tq' => 'TQ洽谈通(www.tq.cn)',
  'qiao' => '百度商桥(qiao.baidu.com)',
);
?>