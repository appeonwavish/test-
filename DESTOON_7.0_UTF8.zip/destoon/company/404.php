<?php
require '../404.php';
?>