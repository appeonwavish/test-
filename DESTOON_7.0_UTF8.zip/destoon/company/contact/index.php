<?php
define('DT_REWRITE', true);
require '../config.inc.php';
require '../../common.inc.php';
$file = 'contact';
require DT_ROOT.'/module/'.$module.'/index.inc.php';
?>